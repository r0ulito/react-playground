import React from "react";

export default function TodoInput({ text, onInputChange, onKeyEvent }) {
  return (
    <>
    <input type="text" value={text} onChange={onInputChange} onKeyDown={onKeyEvent} />
    </>
  );
}
