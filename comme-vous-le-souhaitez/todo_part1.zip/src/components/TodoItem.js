import React from "react";

export default function TodoItem({ todo }) {
  return (
    <div>
    { todo.isCompleted ? 
        <span>Complete</span> 
      : 
        <span>Uncomplete</span>
    }
    <span>{todo.title}</span>
    </div>
  );
}
