import React from "react";
import TodoItem from "./TodoItem";

export default function TodoList( { items }) {
  return (
    <>
    {items.map(todo => (<TodoItem key={todo.id} todo={todo} />))}
    </>
  );
}
