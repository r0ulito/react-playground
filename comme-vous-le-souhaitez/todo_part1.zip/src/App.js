import logo from "./logo.svg";
import "./App.css";
import TodoInput from "./components/TodoInput";
import TodoFilter from "./components/TodoFilter";
import TodoList from "./components/TodoList";
import { useEffect, useState } from "react";

const todoModel = {
  id: 1,
  title: "",
  isCompleted: false,
  isEditing: false
}

function App() {
  const [newTodo, setNewTodo] = useState(todoModel);
  const [todoCounter, setTodoCounter] = useState(1);
  const [todos, setTodos] = useState([]);

  useEffect(() => {
    console.log(todos)
  }, [todos])


  const handleInputChange = ({ target : { value }}) => {
    setNewTodo(Object.assign({}, todoModel, { title: value}))
  }

  const handleInputKeyEvent = ({ key }) => {
    switch(key) {
      case "Enter":
        if(newTodo.title !== '') {
          setTodos(state => [...state, newTodo])
          setTodoCounter(oldCounter => {
            Object.assign(todoModel, { id: todoCounter + 1});
            return oldCounter + 1;
          })
          
          setNewTodo(
            Object.assign({}, todoModel, {title: ""})
          )
        }
        break;
      case "Escape":
        setNewTodo(todoModel)
        break;
    }
  }
  return (
    <div className="App">
      <TodoInput text={newTodo.title} onInputChange={handleInputChange} onKeyEvent={handleInputKeyEvent} />
      <TodoFilter />
      <TodoList items={todos} />
      {/* Le composant doit afficher :
        - L'input
        - le composant qui affiche les filtres
        - La liste des todos 
      */}
    </div>
  );
}

export default App;
